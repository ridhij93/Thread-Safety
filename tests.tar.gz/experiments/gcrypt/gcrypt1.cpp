#include <iostream>
#include <string>
#include <cstdlib>
#include <gcrypt.h>
#include "aes.h"

#define GCRY_CIPHER GCRY_CIPHER_AES128   
#define GCRY_MODE GCRY_CIPHER_MODE_ECB 

using namespace std;

string aes::aes(string a) {
    key = a;
    keyLength = gcry_cipher_get_algo_keylen(GCRY_CIPHER);

    gcry_control (GCRYCTL_DISABLE_SECMEM, 0);
    gcry_control (GCRYCTL_INITIALIZATION_FINISHED, 0);
    gcry_cipher_open(&handle, GCRY_CIPHER, GCRY_MODE, 0);
    gcry_cipher_setkey(handle, key.c_str(), keyLength);
}

string aes::encrypt(string text) {
    size_t textLength = text.size() + 1;
    char * encBuffer = (char *)malloc(textLength);
    gcry_cipher_encrypt(handle, encBuffer, textLength, text.c_str(), textLength);
    string ret (encBuffer);
    return ret;
}

string aes::decrypt(string text) {
    size_t textLength = text.size() + 1;
    char * decBuffer = (char * )malloc(textLength);
    gcry_cipher_decrypt(handle, decBuffer, textLength, text.c_str(), textLength);
    string ret (decBuffer);
    return ret;
}
