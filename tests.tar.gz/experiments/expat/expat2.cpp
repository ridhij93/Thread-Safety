#include <expat.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <iostream>

#define BUFFER_SIZE 100000
using namespace std;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
/* track the current level in the xml tree */
static int      depth = 0;

static char    *last_content;
 struct arg_struct {
    char *arg1;
 size_t arg2;
} ;
/* first when start element is encountered */
void
start_element(void *data, const char *element, const char **attribute)
{
    int             i;

    for (i = 0; i < depth; i++) {
        printf(" ");
    }

    printf("%s", element);

    for (i = 0; attribute[i]; i += 2) {
        printf(" %s= '%s'", attribute[i], attribute[i + 1]);
    }

    printf("\n");
    depth++;
}

/* decrement the current level of the tree */
void
end_element(void *data, const char *el)
{
    int             i;
    for (i = 0; i < depth; i++) {
        printf(" ");
    }
    printf("Content of element %s was \"%s\"\n", el, last_content);
    depth--;
}

void handle_data(void *data, const char *content, int length)
{
    char *tmp = (char*)malloc(length);
    strncpy(tmp, content, length);
    tmp[length] = '\0';
    data = (void *) tmp;
    last_content = tmp;         /* TODO: concatenate the text nodes? */
}

void * parse_xml(void * arguments)
{
struct arg_struct *args = (struct arg_struct *)arguments;
int *x1;
 char *buff =args->arg1;
 size_t buff_size=args->arg2;
    FILE           *fp;
    fp = fopen("FirstTest.xml", "r");
    if (fp == NULL) {
        printf("Failed to open file\n");
        *x1=1;
    }
 //pthread_mutex_lock(&lock);
cout << "start\n";
    XML_Parser      parser = XML_ParserCreate(NULL);
    XML_SetElementHandler(parser, start_element, end_element);
    XML_SetCharacterDataHandler(parser, handle_data);

    memset(buff, 0, buff_size);
    printf("strlen(buff) before parsing: %d\n", strlen(buff));

    size_t          file_size = 0;
    file_size = fread(buff, sizeof(char), buff_size, fp);

    /* parse the xml */
    if (XML_Parse(parser, buff, strlen(buff), XML_TRUE) == XML_STATUS_ERROR) {
        printf("Error: %s\n", XML_ErrorString(XML_GetErrorCode(parser)));
    }

    fclose(fp);
    XML_ParserFree(parser);
 //pthread_mutex_unlock(&lock);
cout << "end\n";
  *x1= 0;
pthread_exit(x1);
}

int
main(int argc, char **argv)
{pthread_t threads[10];
    int result;
    char buffer[BUFFER_SIZE];
int i,rc;
struct arg_struct args;
   // result = parse_xml(buffer, BUFFER_SIZE);
for( i=0; i < 10; i++ ){
      cout << "main() : creating thread, " << i << endl;
      rc = pthread_create(&threads[i], NULL, 
                          parse_xml, &args);
printf("Result is %i\n", rc);
      if (rc){
         cout << "Error:unable to create thread," << rc << endl;
         exit(-1);
      }
   }
    
    return 0;
}
