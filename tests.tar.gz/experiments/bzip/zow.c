#include <stdio.h>
#include <zlib.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
/* CHUNK is the size of the memory chunk used by the zlib routines. */

#define CHUNK 0x60000

/* The following macro calls a zlib routine and checks the return
   value. If the return value ("status") is not OK, it prints an error
   message and exits the program. Zlib's error statuses are all less
   than zero. */

#define CALL_ZLIB(x) {                                                  \
        int status;                                                     \
        status = x;                                                     \
        if (status < 0) {                                               \
            fprintf (stderr,                                            \
                     "%s:%d: %s returned a bad status of %d.\n",        \
                     __FILE__, __LINE__, #x, status);                   \
            exit (EXIT_FAILURE);                                        \
        }                                                               \
    }

/* These are parameters to deflateInit2. See
   http://zlib.net/manual.html for the exact meanings. */

#define windowBits 15
#define GZIP_ENCODING 16

 void* strm_init (void * strm)
{
 z_stream *strm1;
strm1=(z_stream*) (malloc(sizeof(z_stream_s)));
strm1=(z_stream *)strm;  

    strm1->zalloc = Z_NULL;

  strm1->zfree  = Z_NULL;
  strm1->opaque = Z_NULL;
//pthread_mutex_lock(&lock);

printf("start\n");
    CALL_ZLIB (deflateInit2 (strm1, Z_DEFAULT_COMPRESSION, Z_DEFLATED,
                             windowBits | GZIP_ENCODING, 8,
                             Z_DEFAULT_STRATEGY));
//pthread_mutex_unlock(&lock);

printf("end\n");
}

/* Example text to print out. */

static const char * message = 
"Shall I compare thee to a summer's days?\n"
"Thou art more lovely and more temperate:\n"
"Rough winds do shake the darling buds of May,\n"
"And summer's lease hath all too short a dates;\n"
;

int main ()
{
    unsigned char out[CHUNK];
int rc;
pthread_t threads[10];

int i;
  

   for( i=0; i < 10; i++ ){
    z_stream strm;
rc = pthread_create(&threads[i], NULL, 
                          strm_init, &strm);

   // strm_init (& strm);

    strm.next_in = (unsigned char *) message;
    strm.avail_in = strlen (message);
    do {
        int have;
        strm.avail_out = CHUNK;
        strm.next_out = out;
        CALL_ZLIB (deflate (& strm, Z_FINISH));
        have = CHUNK - strm.avail_out;
        fwrite (out, sizeof (char), have, stdout);
    }
    while (strm.avail_out == 0);
    deflateEnd (& strm);
}
    return 0;
}
