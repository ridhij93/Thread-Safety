#include <Magick++.h> 
#include <iostream> 
#include "magick.h". 
using namespace std; 
using namespace Magick; 
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void* code(void * image)
{ 
Image image1=*(Image*)image;
//Image image2=image1;
try {

    // Read a file into image object 
 //pthread_mutex_lock(&lock);
cout << "start" << endl;
    image1.read( "samp.png" );

    // Crop the image to specified size (width, height, xOffset, yOffset)
    image1.crop( Geometry(100,100, 100, 100) );

    // Write the image to a file 

    image1.write( "logo.png" ); 
//pthread_mutex_unlock(&lock);
cout << "stop" << endl;
  } 
  catch( Exception &error_ ) 
    { 
      cout << "Caught exception: " << error_.what() << endl; 
     // return 1; 

    } 

}

int main(int argc,char **argv) 
{ pthread_t threads[10];
  InitializeMagick(*argv);
int i,rc;
  // Construct the image object. Seperating image construction from the 
  // the read operation ensures that a failure to read the image file 
  // doesn't render the image object useless. 
  Image image;
//image.read( "samp.png" );
//image.crop( Geometry(100,100, 100, 100) );
 /* try { 
    // Read a file into image object 
    image.read( "logo:" );

    // Crop the image to specified size (width, height, xOffset, yOffset)
    image.crop( Geometry(100,100, 100, 100) );

    // Write the image to a file 
    image.write( "logo.png" ); 
  } 
  catch( Exception &error_ ) 
    { 
      cout << "Caught exception: " << error_.what() << endl; 
      return 1; 
    } */
for( i=0; i < 10; i++ ){
      cout << "main() : creating thread, " << i << endl;
      rc = pthread_create(&threads[i], NULL, 
                          code, &image);
      if (rc){
         cout << "Error:unable to create thread," << rc << endl;
         exit(-1);
      }
   }
  return 0; 
}
