#ifndef DYN_H_
#define DYN_H_

class Dyn{

	public: 
		void interleave(); 

};

#endif
